try:
    import pygbag.aio as asyncio
except ImportError:  # Desktop fallback when running outside pygbag.
    import asyncio

from game import main


asyncio.run(main())
